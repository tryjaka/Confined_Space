# GodotMaze
Godot maze generator using Optimal Path algorythm.
![alt tag](https://github.com/landroo/GodotMaze/blob/master/maze.png)
Solve method added :)
![alt tag](https://github.com/landroo/GodotMaze/blob/master/tile.png)
Tile maze added :)
![alt tag](https://github.com/landroo/GodotMaze/blob/master/pipe.png)
Pipe maze added :)

